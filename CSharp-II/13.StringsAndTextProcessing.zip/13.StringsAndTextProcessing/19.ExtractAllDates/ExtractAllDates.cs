﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

class ExtractAllDates
{
    static void Main()
    {
        Console.WriteLine("This program extracts from a given text all dates\n" + 
            "that match the format DD.MM.YYYY.");
        Console.Write("\nPlease enter some text: ");
        string input = Console.ReadLine();
    }
} // To be finished

